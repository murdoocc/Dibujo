package proyecto1dibujo;

import java.io.File;
import javafx.animation.ScaleTransition;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.effect.DropShadow;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Background;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import javafx.scene.media.MediaView;
import javafx.scene.paint.Color;
import javafx.scene.shape.ArcTo;
import javafx.scene.shape.Circle;
import javafx.scene.shape.ClosePath;
import javafx.scene.shape.CubicCurve;
import javafx.scene.shape.CubicCurveTo;
import javafx.scene.shape.Ellipse;
import javafx.scene.shape.FillRule;
import javafx.scene.shape.HLineTo;
import javafx.scene.shape.LineTo;
import javafx.scene.shape.MoveTo;
import javafx.scene.shape.Path;
import javafx.scene.shape.Polygon;
import javafx.scene.shape.QuadCurveTo;
import javafx.scene.shape.VLineTo;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.scene.transform.Scale;
import javafx.stage.Stage;
import javafx.util.Duration;

/**
 *
 * @author murdo
 */
public class Proyecto1Dibujo extends Application {
    
    
    private Button btnFondo;
    
    private Button btnFace;
    private Button btnEyes;
    private Button btnEyeBrows;
    private Button btnSenios;
    private Button btnNose;
    private Button btnMouth;
    private Button btnHair;
    private Button btnEars;
    private Button btnWeapon;
    
    private Pane root;
    
    @Override
    public void start(Stage stage) {
        root = new Pane();
        Scene scene = new Scene(root, 700, 675);
        stage.setScene(scene);
        stage.setTitle("");
        
        root.setOnMouseClicked(evt -> {
            System.out.println("x:"+evt.getX());
            System.out.println("y:"+evt.getY());
        });
        
        btnFondo = new Button("Fondo");
        btnFondo.setLayoutX(0);
        btnFondo.setLayoutY(0);
        btnFondo.setOnAction(evt -> {
            /*Path fondo = new Path();
            
            MoveTo bambu1 = new MoveTo();
            bambu1.setX(50);
            bambu1.setY(0);
            
            VLineTo lineaV1 = new VLineTo();
            lineaV1.setY(375);
            
            MoveTo bambu2 = new MoveTo();
            bambu2.setX(100);
            bambu2.setY(0);
            
            VLineTo lineaV2 = new VLineTo();
            lineaV2.setY(375);
            
            fondo.getElements().addAll(bambu1,lineaV1,bambu2,lineaV2);
            fondo.setStrokeWidth(20);
            fondo.setStroke(Color.GREEN);*/
            
            
            
            
            //root.getChildren().add(fondo);
        });
        
        
        btnFace = new Button("Cara");
        btnFace.setBackground(Background.EMPTY);
        btnFace.setLayoutX(0);
        btnFace.setLayoutY(350);
        btnFace.setOnAction(evt ->{
            Polygon poliCara = new Polygon();
            Path cabeza = new Path();

            MoveTo moveTo1 = new MoveTo();
            moveTo1.setX(271.0f);
            moveTo1.setY(232.0f);
            QuadCurveTo quadTo1 = new QuadCurveTo();
            quadTo1.setX(322.0f);
            quadTo1.setY(192.0f);
            quadTo1.setControlX(278.0f);
            quadTo1.setControlY(235.0f);

            MoveTo moveTo2 = new MoveTo();
            moveTo2.setX(322);
            moveTo2.setY(192);
            QuadCurveTo quadTo2 = new QuadCurveTo();
            quadTo2.setX(370.0f);
            quadTo2.setY(180.0f);
            quadTo2.setControlX(355.0f);
            quadTo2.setControlY(175.0f);

            MoveTo moveTo3 = new MoveTo();
            moveTo3.setX(370);
            moveTo3.setY(180);
            QuadCurveTo quadTo3 = new QuadCurveTo();
            quadTo3.setX(425.0f);
            quadTo3.setY(178.0f);
            quadTo3.setControlX(365.0f);
            quadTo3.setControlY(190.0f);

            MoveTo moveTo4 = new MoveTo();
            moveTo4.setX(425);
            moveTo4.setY(178);
            QuadCurveTo quadTo4 = new QuadCurveTo();
            quadTo4.setX(480.0f);
            quadTo4.setY(215.0f);
            quadTo4.setControlX(460.0f);
            quadTo4.setControlY(180.0f);

            MoveTo moveTo5 = new MoveTo();
            moveTo5.setX(480);
            moveTo5.setY(215);
            QuadCurveTo quadTo5 = new QuadCurveTo();
            quadTo5.setX(506.0f);
            quadTo5.setY(233.0f);
            quadTo5.setControlX(480.0f);
            quadTo5.setControlY(220.0f);

            MoveTo moveTo6 = new MoveTo();
            moveTo6.setX(506);
            moveTo6.setY(233);
            QuadCurveTo quadTo6 = new QuadCurveTo();
            quadTo6.setX(350.0f);
            quadTo6.setY(312.0f);
            quadTo6.setControlX(515.0f);
            quadTo6.setControlY(335.0f);

            MoveTo moveTo7 = new MoveTo();
            moveTo7.setX(350);
            moveTo7.setY(312);
            QuadCurveTo quadTo7 = new QuadCurveTo();
            quadTo7.setX(271.0f);
            quadTo7.setY(232.0f);
            quadTo7.setControlX(270.0f);
            quadTo7.setControlY(305.0f);
            
            Double posi[] = {271.0,232.0,322.0,192.0,370.0,180.0,425.0,178.0,480.0,215.0,506.0,233.0,350.0,312.0};
            //poliCara.getPoints().addAll(posi);
            //poliCara.setFill(Color.AQUA);
            //poliCara.setFill(Color.TRANSPARENT);
            //poliCara.setStroke(Color.BLACK);
            //poliCara.setStrokeWidth(1);
            
            cabeza.getElements().addAll(moveTo1, 
                    quadTo1, 
                    quadTo2, 
                    quadTo3, 
                    quadTo4, 
                    quadTo5, 
                    quadTo6, 
                    quadTo7);       
            cabeza.setStrokeWidth(2);     
                     
            //cabeza.setFillRule(FillRule.NON_ZERO);             
            
            //cabeza.fillRuleProperty().setValue(FillRule.EVEN_ODD);
            cabeza.setFill(Color.color(0.9, 0.4, 0.1));
            
            //cabeza.setFill(Color.INDIANRED);

            
            root.getChildren().addAll(cabeza,poliCara);
            
        });
        
        btnEyes = new Button("Ojos");
        btnEyes.setBackground(Background.EMPTY);
        btnEyes.setTextFill(Color.GREEN);
        btnEyes.setLayoutX(50);
        btnEyes.setLayoutY(350);
        btnEyes.setOnAction(evt -> {
            Ellipse eye1 = new Ellipse();
            eye1.setCenterX(350);
            eye1.setCenterY(245);
            eye1.setRadiusX(27);
            eye1.setRadiusY(18);
            eye1.setStrokeWidth(1);
            eye1.setFill(Color.BLACK);
            eye1.setStroke(Color.BLACK);

            Ellipse eye2 = new Ellipse();
            eye2.setCenterX(437);
            eye2.setCenterY(245);
            eye2.setRadiusX(27);
            eye2.setRadiusY(18);
            eye2.setStrokeWidth(1);
            eye2.setFill(Color.BLACK);
            eye2.setStroke(Color.BLACK);

            Circle eye3 = new Circle();
            eye3.setCenterX(346.5);
            eye3.setCenterY(240);        
            eye3.setRadius(4);
            eye3.setStrokeWidth(1);
            eye3.setFill(Color.WHITE);
            eye3.setStroke(Color.BLACK);

            Circle eye4 = new Circle();
            eye4.setCenterX(360);
            eye4.setCenterY(244);
            eye4.setRadius(4);
            eye4.setStrokeWidth(1);
            eye4.setFill(Color.WHITE);
            eye4.setStroke(Color.BLACK);  

            Circle eye5 = new Circle();
            eye5.setCenterX(432);
            eye5.setCenterY(240);        
            eye5.setRadius(4);
            eye5.setStrokeWidth(1);
            eye5.setFill(Color.WHITE);
            eye5.setStroke(Color.BLACK);

            Circle eye6 = new Circle();
            eye6.setCenterX(447);
            eye6.setCenterY(244);
            eye6.setRadius(4);
            eye6.setStrokeWidth(1);
            eye6.setFill(Color.WHITE);
            eye6.setStroke(Color.BLACK);
            
            Group eyes = new Group(eye1, eye2, eye3, eye4, eye5, eye6);
            
            root.getChildren().addAll(eyes);
        });
        
        btnEyeBrows = new Button("Cejas");       
        btnEyeBrows.setBackground(Background.EMPTY);   
        btnEyeBrows.setTextFill(Color.RED);
        btnEyeBrows.setLayoutX(100);
        btnEyeBrows.setLayoutY(350);       
        btnEyeBrows.setOnAction(evt ->{
            Path cejas1 = new Path();

            MoveTo moveTo8 = new MoveTo();
            moveTo8.setX(318);
            moveTo8.setY(218);
            QuadCurveTo ceja1 = new QuadCurveTo();
            ceja1.setX(385.0f);
            ceja1.setY(227.0f);
            ceja1.setControlX(350.0f);
            ceja1.setControlY(205.0f);

            MoveTo moveTo9 = new MoveTo();
            moveTo9.setX(385);
            moveTo9.setY(227);
            QuadCurveTo ceja2 = new QuadCurveTo();
            ceja2.setX(374.0f);
            ceja2.setY(231.0f);
            ceja2.setControlX(382.0f);
            ceja2.setControlY(232.0f);

            MoveTo moveTo10 = new MoveTo();
            moveTo10.setX(374);
            moveTo10.setY(231);
            QuadCurveTo ceja3 = new QuadCurveTo();
            ceja3.setX(326.0f);
            ceja3.setY(222.0f);
            ceja3.setControlX(350.0f);
            ceja3.setControlY(213.0f);

            MoveTo moveTo11 = new MoveTo();
            moveTo11.setX(318);
            moveTo11.setY(218);
            QuadCurveTo ceja4 = new QuadCurveTo();
            ceja4.setX(326.0f);
            ceja4.setY(222.0f);
            ceja4.setControlX(320.0f);
            ceja4.setControlY(221.0f);
            
            Path cejas2 = new Path();

            MoveTo moveTo12 = new MoveTo();
            moveTo12.setX(405);
            moveTo12.setY(222);
            QuadCurveTo ceja5 = new QuadCurveTo();
            ceja5.setX(465.0f);
            ceja5.setY(222.0f);
            ceja5.setControlX(455.0f);
            ceja5.setControlY(205.0f);

            MoveTo moveTo13 = new MoveTo();
            moveTo13.setX(465);
            moveTo13.setY(222);
            QuadCurveTo ceja6 = new QuadCurveTo();
            ceja6.setX(408.0f);
            ceja6.setY(232.0f);
            ceja6.setControlX(450.0f);
            ceja6.setControlY(213.0f);

            MoveTo moveTo14 = new MoveTo();
            moveTo14.setX(408);
            moveTo14.setY(232);
            QuadCurveTo ceja7 = new QuadCurveTo();
            ceja7.setX(405.0f);
            ceja7.setY(222.0f);
            ceja7.setControlX(400.0f);
            ceja7.setControlY(227.0f);
            
            cejas1.getElements().addAll(moveTo8,
                    ceja1, 
                    ceja2, 
                    ceja3, 
                    ceja4);
            cejas1.setStrokeWidth(2);
            
            cejas1.setFill(Color.BLACK);
            
            cejas2.getElements().addAll(moveTo12,
                    ceja5,
                    ceja6,
                    ceja7);
            cejas2.setStrokeWidth(2);
            cejas2.setFill(Color.BLACK);
             
            root.getChildren().addAll(cejas1,cejas2);
        });
                
        btnSenios = new Button("Seño facial");
        btnSenios.setBackground(Background.EMPTY);
        btnSenios.setTextFill(Color.BLUE);
        btnSenios.setLayoutX(155);
        btnSenios.setLayoutY(350);
        btnSenios.setOnAction(evt ->{
            Path senios = new Path();
        
            MoveTo moveTo15 = new MoveTo();
            moveTo15.setX(399);
            moveTo15.setY(222);
            QuadCurveTo senio1 = new QuadCurveTo();
            senio1.setX(407.0f);
            senio1.setY(216.0f);
            senio1.setControlX(405.0f);
            senio1.setControlY(215.0f);

            MoveTo moveTo16 = new MoveTo();
            moveTo16.setX(386);
            moveTo16.setY(222);
            QuadCurveTo senio2 = new QuadCurveTo();
            senio2.setX(380.0f);
            senio2.setY(216.0f);
            senio2.setControlX(385.0f);
            senio2.setControlY(215.0f);

            MoveTo moveTo17 = new MoveTo();
            moveTo17.setX(387);
            moveTo17.setY(287);
            QuadCurveTo senio3 = new QuadCurveTo();
            senio3.setX(403.0f);
            senio3.setY(286.0f);
            senio3.setControlX(392.0f);
            senio3.setControlY(292.0f);
            
            senios.getElements().addAll(moveTo15,senio1, moveTo16, senio2, moveTo17, senio3);
            senios.setStrokeWidth(2);
            
            root.getChildren().add(senios);
        });
        
        btnNose = new Button("Nariz");
        btnNose.setLayoutX(240);
        btnNose.setLayoutY(350);
        btnNose.setBackground(Background.EMPTY);
        btnNose.setTextFill(Color.BROWN);
        btnNose.setOnAction(evt -> {
            Path nariz = new Path();
        
            MoveTo moveTo18 = new MoveTo();
            moveTo18.setX(385);
            moveTo18.setY(251);
            QuadCurveTo nariz1 = new QuadCurveTo();
            nariz1.setX(403.0f);
            nariz1.setY(249.0f);
            nariz1.setControlX(392.0f);
            nariz1.setControlY(246.0f);        
            
            nariz.getElements().addAll(moveTo18,nariz1);
            nariz.setStrokeWidth(2);
            
            root.getChildren().add(nariz);
        });
        
        btnMouth = new Button("Boca");
        btnMouth.setBackground(Background.EMPTY);
        btnMouth.setTextFill(Color.GREEN);
        btnMouth.setLayoutX(290);
        btnMouth.setLayoutY(350);
        btnMouth.setOnAction(evt ->{
            Path boca = new Path();
        
            MoveTo moveTo19 = new MoveTo();
            moveTo19.setX(364);
            moveTo19.setY(276);
            QuadCurveTo boca1 = new QuadCurveTo();
            boca1.setX(417.0f);
            boca1.setY(270.0f);
            boca1.setControlX(392.0f);
            boca1.setControlY(285.0f);        

            MoveTo moveTo20 = new MoveTo();
            moveTo20.setX(361.0f);
            moveTo20.setY(276.5f);
            QuadCurveTo boca2 = new QuadCurveTo();
            boca2.setX(362.0f);
            boca2.setY(275.0f);
            boca2.setControlX(361.5f);
            boca2.setControlY(276.0f);   

            MoveTo moveTo21 = new MoveTo();
            moveTo21.setX(413.0f);
            moveTo21.setY(266.5f);
            QuadCurveTo boca3 = new QuadCurveTo();
            boca3.setX(424.0f);
            boca3.setY(271.0f);
            boca3.setControlX(415.5f);
            boca3.setControlY(271.0f);
            
            boca.getElements().addAll(moveTo19,boca1, moveTo20, boca2, moveTo21, boca3);
            boca.setStrokeWidth(2);
            
            root.getChildren().add(boca);
        });
        
        btnHair = new Button("Cabello");
        btnHair.setBackground(Background.EMPTY);        
        btnHair.setLayoutX(340);
        btnHair.setLayoutY(350);
        btnHair.setOnAction(evt->{
            Path cabello = new Path();
        
            MoveTo moveToCa1 = new MoveTo();
            moveToCa1.setX(277.0f);
            moveToCa1.setY(271.5f);
            QuadCurveTo cabello1 = new QuadCurveTo();
            cabello1.setX(187.0f);
            cabello1.setY(316.0f);
            cabello1.setControlX(233.0f);
            cabello1.setControlY(270.0f);

            MoveTo moveToCa2 = new MoveTo();
            moveToCa2.setX(187);
            moveToCa2.setY(316);
            CubicCurveTo cabello2 = new CubicCurveTo();
            cabello2.setX(175.0f);
            cabello2.setY(293.0f);
            cabello2.setControlX1(170.0f);
            cabello2.setControlY1(298.0f);
            cabello2.setControlX2(193.0f);
            cabello2.setControlY2(302.0f);

            MoveTo moveToCa3 = new MoveTo();
            moveToCa3.setX(175);
            moveToCa3.setY(293);
            CubicCurveTo cabello3 = new CubicCurveTo();
            cabello3.setX(194.0f);
            cabello3.setY(240.0f);
            cabello3.setControlX1(192.0f);
            cabello3.setControlY1(260.0f);
            cabello3.setControlX2(161.0f);
            cabello3.setControlY2(268.0f);

            MoveTo moveToCa4 = new MoveTo();
            moveToCa4.setX(194);
            moveToCa4.setY(240);
            CubicCurveTo cabello4 = new CubicCurveTo();
            cabello4.setX(205.0f);
            cabello4.setY(200.0f);
            cabello4.setControlX1(190.0f);
            cabello4.setControlY1(210.0f);
            cabello4.setControlX2(210.0f);
            cabello4.setControlY2(220.0f);

            MoveTo moveToCa5 = new MoveTo();
            moveToCa5.setX(205);
            moveToCa5.setY(200);
            CubicCurveTo cabello5 = new CubicCurveTo();
            cabello5.setX(265.0f);
            cabello5.setY(160.0f);
            cabello5.setControlX1(230.0f);
            cabello5.setControlY1(185.0f);
            cabello5.setControlX2(245.0f);
            cabello5.setControlY2(153.0f);

            MoveTo moveToCa6 = new MoveTo();
            moveToCa6.setX(265);
            moveToCa6.setY(160);
            CubicCurveTo cabello6 = new CubicCurveTo();
            cabello6.setX(332.0f);
            cabello6.setY(133.0f);
            cabello6.setControlX1(285.0f);
            cabello6.setControlY1(137.0f);
            cabello6.setControlX2(310.0f);
            cabello6.setControlY2(150.0f);

            MoveTo moveToCa7 = new MoveTo();
            moveToCa7.setX(332);
            moveToCa7.setY(133);
            CubicCurveTo cabello7 = new CubicCurveTo();
            cabello7.setX(395.0f);
            cabello7.setY(136.0f);
            cabello7.setControlX1(370.0f);
            cabello7.setControlY1(138.0f);
            cabello7.setControlX2(365.0f);
            cabello7.setControlY2(130.0f);

            MoveTo moveToCa8 = new MoveTo();
            moveToCa8.setX(395);
            moveToCa8.setY(136);
            CubicCurveTo cabello8 = new CubicCurveTo();
            cabello8.setX(445.0f);
            cabello8.setY(132.0f);
            cabello8.setControlX1(410.0f);
            cabello8.setControlY1(130.0f);
            cabello8.setControlX2(425.0f);
            cabello8.setControlY2(138.0f);

            MoveTo moveToCa9 = new MoveTo();
            moveToCa9.setX(445);
            moveToCa9.setY(132);
            CubicCurveTo cabello9 = new CubicCurveTo();
            cabello9.setX(476.0f);
            cabello9.setY(148.0f);
            cabello9.setControlX1(480.0f);
            cabello9.setControlY1(137.0f);
            cabello9.setControlX2(473.0f);
            cabello9.setControlY2(143.0f);

            MoveTo moveToCa10 = new MoveTo();
            moveToCa10.setX(476);
            moveToCa10.setY(148);
            CubicCurveTo cabello10 = new CubicCurveTo();
            cabello10.setX(517.0f);
            cabello10.setY(165.0f);
            cabello10.setControlX1(495.0f);
            cabello10.setControlY1(145.0f);
            cabello10.setControlX2(500.0f);
            cabello10.setControlY2(160.0f);

            MoveTo moveToCa11 = new MoveTo();
            moveToCa11.setX(517);
            moveToCa11.setY(165);
            CubicCurveTo cabello11 = new CubicCurveTo();
            cabello11.setX(551.0f);
            cabello11.setY(203.0f);
            cabello11.setControlX1(519.0f);
            cabello11.setControlY1(175.0f);
            cabello11.setControlX2(555.0f);
            cabello11.setControlY2(180.0f);

            MoveTo moveToCa12 = new MoveTo();
            moveToCa12.setX(551);
            moveToCa12.setY(203);
            CubicCurveTo cabello12 = new CubicCurveTo();
            cabello12.setX(573.0f);
            cabello12.setY(235.0f);
            cabello12.setControlX1(570.0f);
            cabello12.setControlY1(215.0f);
            cabello12.setControlX2(556.0f);
            cabello12.setControlY2(220.0f);

            MoveTo moveToCa13 = new MoveTo();
            moveToCa13.setX(573);
            moveToCa13.setY(235);
            CubicCurveTo cabello13 = new CubicCurveTo();
            cabello13.setX(585.0f);
            cabello13.setY(275.0f);
            cabello13.setControlX1(568.0f);
            cabello13.setControlY1(260.0f);
            cabello13.setControlX2(587.0f);
            cabello13.setControlY2(272.0f);

            MoveTo moveToCa14 = new MoveTo();
            moveToCa14.setX(585.0f);
            moveToCa14.setY(275.5f);
            QuadCurveTo cabello14 = new QuadCurveTo();
            cabello14.setX(514.0f);
            cabello14.setY(249.0f);
            cabello14.setControlX(580.0f);
            cabello14.setControlY(285.0f);            
            
            QuadCurveTo cabello15 = new QuadCurveTo();
            cabello15.setX(506.0f);
            cabello15.setY(233.5f);
            cabello15.setControlX(526.0f);
            cabello15.setControlY(233.0f);
            
            CubicCurveTo cabello16 = new CubicCurveTo();
            cabello16.setX(425.0f);
            cabello16.setY(178.0f);
            cabello16.setControlX1(471.0f);
            cabello16.setControlY1(220.0f);
            cabello16.setControlX2(468.0f);
            cabello16.setControlY2(178.0f);
            
            CubicCurveTo cabello17 = new CubicCurveTo();
            cabello17.setX(322.0f);
            cabello17.setY(192.0f);
            cabello17.setControlX1(350.0f);
            cabello17.setControlY1(195.0f);
            cabello17.setControlX2(385.0f);
            cabello17.setControlY2(165.0f);
            
            QuadCurveTo cabello18 = new QuadCurveTo();
            cabello18.setX(271.5f);
            cabello18.setY(231.5f);
            cabello18.setControlX(288.0f);
            cabello18.setControlY(226.0f);
            
            QuadCurveTo cabello19 = new QuadCurveTo();
            cabello19.setX(277.0f);
            cabello19.setY(271.0f);
            cabello19.setControlX(272.0f);
            cabello19.setControlY(250.0f);
            
            cabello.getElements().addAll(moveToCa1,
                    cabello1,
                    cabello2,
                    cabello3,
                    cabello4,
                    cabello5,
                    cabello6,
                    cabello7,
                    cabello8,
                    cabello9,
                    cabello10,
                    cabello11,
                    cabello12,
                    cabello13,
                    cabello14,
                    cabello15,
                    cabello16,
                    cabello17,
                    cabello18,
                    cabello19);
            cabello.setStrokeWidth(2);                      
            
            cabello.setFill(Color.BLACK);
            
            root.getChildren().add(cabello);
        });
        
        btnEars = new Button("Orejas");
        btnEars.setBackground(Background.EMPTY);
        btnEars.setTextFill(Color.RED);
        btnEars.setLayoutX(400);
        btnEars.setLayoutY(350);        
        btnEars.setOnAction(evt->{
            Path orejas1 = new Path();
        
            MoveTo moveTo22 = new MoveTo();
            moveTo22.setX(270.0f);
            moveTo22.setY(232.5f);
            QuadCurveTo oreja1 = new QuadCurveTo();
            oreja1.setX(272.0f);
            oreja1.setY(256.0f);
            oreja1.setControlX(250.5f);
            oreja1.setControlY(242.0f);
            
            Path orejas2 = new Path();
            
            MoveTo moveTo23 = new MoveTo();
            moveTo23.setX(506.0f);
            moveTo23.setY(233.5f);
            QuadCurveTo oreja2 = new QuadCurveTo();
            oreja2.setX(506.0f);
            oreja2.setY(255.0f);
            oreja2.setControlX(531.5f);
            oreja2.setControlY(235.0f);
            
            orejas1.getElements().addAll(moveTo22,oreja1);
            orejas1.setStrokeWidth(2);
            
            orejas1.getElements().addAll(moveTo23, oreja2);
            orejas1.setStrokeWidth(2);
            
            orejas1.setFill(Color.color(0.9, 0.4, 0.1));
            orejas2.setFill(Color.color(0.9, 0.4, 0.1));
            
            root.getChildren().addAll(orejas1,orejas2);
        });        
        
        btnWeapon = new Button("Arma");
        btnWeapon.setBackground(Background.EMPTY);
        btnWeapon.setTextFill(Color.BLUE);        
        btnWeapon.setLayoutX(460);
        btnWeapon.setLayoutY(350);
        btnWeapon.setOnAction(evt -> {
            Path armaa1 = new Path();
        
            MoveTo moveTo24 = new MoveTo();
            moveTo24.setX(514.0f);
            moveTo24.setY(250.5f);
            QuadCurveTo arma1 = new QuadCurveTo();
            arma1.setX(668.0f);
            arma1.setY(317.0f);
            arma1.setControlX(516.5f);
            arma1.setControlY(251.0f);

            MoveTo moveTo25 = new MoveTo();
            moveTo25.setX(668.0f);
            moveTo25.setY(317.5f);
            QuadCurveTo arma2 = new QuadCurveTo();
            arma2.setX(500.0f);
            arma2.setY(280.0f);
            arma2.setControlX(675.5f);
            arma2.setControlY(360.0f);
            
            QuadCurveTo armi3 = new QuadCurveTo();
            armi3.setX(506.0f);
            armi3.setY(254.0f);
            armi3.setControlX(505.5f);
            armi3.setControlY(264.0f);
            
            QuadCurveTo armi4 = new QuadCurveTo();
            armi4.setX(512.5f);
            armi4.setY(249.5f);
            armi4.setControlX(510.5f);
            armi4.setControlY(251.0f);
            
            Path armaa2 = new Path();

            MoveTo moveTo26 = new MoveTo();
            moveTo26.setX(218.5f);
            moveTo26.setY(189.0f);
            QuadCurveTo arma3 = new QuadCurveTo();
            arma3.setX(46.0f);
            arma3.setY(54.0f);
            arma3.setControlX(15.0f);
            arma3.setControlY(155.0f);

            MoveTo moveTo27 = new MoveTo();
            moveTo27.setX(46.0f);
            moveTo27.setY(54.0f);
            HLineTo arma4 = new HLineTo();
            arma4.setX(26.0f);

            MoveTo moveTo28 = new MoveTo();
            moveTo28.setX(26);
            moveTo28.setY(54);
            CubicCurveTo arma5 = new CubicCurveTo();
            arma5.setX(275.0f);
            arma5.setY(100.0f);
            arma5.setControlX1(78.0f);
            arma5.setControlY1(6.0f);
            arma5.setControlX2(250.0f);
            arma5.setControlY2(1.0f);

            MoveTo moveTo29 = new MoveTo();
            moveTo29.setX(275.5f);
            moveTo29.setY(100.0f);
            QuadCurveTo arma6 = new QuadCurveTo();
            arma6.setX(170.0f);
            arma6.setY(81.0f);
            arma6.setControlX(245.0f);
            arma6.setControlY(77.0f);

            MoveTo moveTo30 = new MoveTo();
            moveTo30.setX(170);
            moveTo30.setY(81);
            CubicCurveTo arma7 = new CubicCurveTo();
            arma7.setX(125.0f);
            arma7.setY(80.0f);
            arma7.setControlX1(200.0f);
            arma7.setControlY1(50.0f);
            arma7.setControlX2(120.0f);
            arma7.setControlY2(35.0f);

            MoveTo moveTo31 = new MoveTo();
            moveTo31.setX(125.5f);
            moveTo31.setY(80.0f);
            QuadCurveTo arma8 = new QuadCurveTo();
            arma8.setX(260.0f);
            arma8.setY(158.0f);
            arma8.setControlX(135.0f);
            arma8.setControlY(120.0f);
            
            CubicCurveTo armi9 = new CubicCurveTo();
            armi9.setX(218.0f);
            armi9.setY(188.0f);
            armi9.setControlX1(253.0f);
            armi9.setControlY1(166.0f);
            armi9.setControlX2(247.0f);
            armi9.setControlY2(156.0f);
            
            Path armaa3 =  new Path();

            MoveTo moveTo32 = new MoveTo();
            moveTo32.setX(653.5f);
            moveTo32.setY(313.0f);
            QuadCurveTo arma9 = new QuadCurveTo();
            arma9.setX(655.0f);
            arma9.setY(330.0f);
            arma9.setControlX(648.0f);
            arma9.setControlY(320.0f);       

            MoveTo moveTo33 = new MoveTo();
            moveTo33.setX(635.5f);
            moveTo33.setY(303.0f);
            QuadCurveTo arma10 = new QuadCurveTo();
            arma10.setX(647.0f);
            arma10.setY(331.0f);
            arma10.setControlX(634.0f);
            arma10.setControlY(312.0f);

            MoveTo moveTo34 = new MoveTo();
            moveTo34.setX(612.5f);
            moveTo34.setY(295.0f);
            QuadCurveTo arma11 = new QuadCurveTo();
            arma11.setX(632.0f);
            arma11.setY(329.0f);
            arma11.setControlX(618.0f);
            arma11.setControlY(312.0f);

            MoveTo moveTo35 = new MoveTo();
            moveTo35.setX(592.5f);
            moveTo35.setY(284.0f);
            QuadCurveTo arma12 = new QuadCurveTo();
            arma12.setX(612.0f);
            arma12.setY(325.0f);
            arma12.setControlX(598.0f);
            arma12.setControlY(312.0f);

            MoveTo moveTo36 = new MoveTo();
            moveTo36.setX(573.5f);
            moveTo36.setY(276.0f);
            QuadCurveTo arma13 = new QuadCurveTo();
            arma13.setX(590.0f);
            arma13.setY(317.0f);
            arma13.setControlX(581.0f);
            arma13.setControlY(306.0f);

            MoveTo moveTo37 = new MoveTo();
            moveTo37.setX(553.5f);
            moveTo37.setY(270.0f);
            QuadCurveTo arma14 = new QuadCurveTo();
            arma14.setX(570.0f);
            arma14.setY(310.0f);
            arma14.setControlX(550.0f);
            arma14.setControlY(275.0f);       

            MoveTo moveTo38 = new MoveTo();
            moveTo38.setX(537.5f);
            moveTo38.setY(263.0f);
            QuadCurveTo arma15 = new QuadCurveTo();
            arma15.setX(549.0f);
            arma15.setY(300.0f);
            arma15.setControlX(536.0f);
            arma15.setControlY(275.0f); 

            MoveTo moveTo39 = new MoveTo();
            moveTo39.setX(540.5f);
            moveTo39.setY(284.0f);
            QuadCurveTo arma16 = new QuadCurveTo();
            arma16.setX(532.0f);
            arma16.setY(292.0f);
            arma16.setControlX(532.0f);
            arma16.setControlY(287.0f); 

            MoveTo moveTo40 = new MoveTo();
            moveTo40.setX(536.5f);
            moveTo40.setY(267.0f);
            QuadCurveTo arma17 = new QuadCurveTo();
            arma17.setX(518.0f);
            arma17.setY(287.0f);
            arma17.setControlX(515.0f);
            arma17.setControlY(283.0f);

            MoveTo moveTo41 = new MoveTo();
            moveTo41.setX(528.5f);
            moveTo41.setY(258.0f);
            QuadCurveTo arma18 = new QuadCurveTo();
            arma18.setX(505.0f);
            arma18.setY(282.0f);
            arma18.setControlX(505.0f);
            arma18.setControlY(275.0f);
            
            armaa1.getElements().addAll(moveTo24,
                    arma1,arma2,armi3,armi4
                    );
            armaa1.setStrokeWidth(2);
            armaa1.setFill(Color.color(0.902, 0.8392, 0.5647));
            
            armaa2.getElements().addAll(moveTo26,
                    arma3,arma4,arma5,arma6,
                    arma7,arma8,armi9);
            armaa2.setFill(Color.color(0.902, 0.8392, 0.5647));
            armaa2.setStrokeWidth(2);
            
            armaa3.getElements().addAll(moveTo32,arma9,
                    moveTo33,arma10,
                    moveTo34,arma11,
                    moveTo35,arma12,
                    moveTo36,arma13,
                    moveTo37,arma14,
                    moveTo38,arma15,
                    moveTo39,arma16,
                    moveTo40,arma17,
                    moveTo41,arma18);
            root.getChildren().addAll(armaa1,armaa2,armaa3);
            armaa3.setStrokeWidth(2);
        });             
                
        ImageView fondo = new ImageView("/fondoMaui.jpg");
            fondo.setFitHeight(400);
            fondo.setFitWidth(720);
            fondo.setDisable(true);
            fondo.setOpacity(0.6);
            fondo.setOnMouseClicked(evt -> {
                System.out.println("x:"+evt.getX());
                System.out.println("y:"+evt.getY());
            });
        
        Button texto = new Button("Texto");
        texto.setLayoutX(570);
        texto.setLayoutY(350);
        texto.setBackground(Background.EMPTY);
        texto.setTextFill(Color.BLUE); 
        texto.setOnMouseClicked(evt->{
            agregarTexto();
        });
        root.getChildren().addAll(fondo,btnFace,btnEyes, btnEyeBrows, btnSenios, btnNose, btnMouth, btnEars, btnHair, btnWeapon, texto);        
        
        stage.setResizable(false);
        scene.setRoot(root);
        stage.show();
        
    }

    
    private void agregarTexto() {
        //Frase celebre del Sr. White...              
        DropShadow ds = new DropShadow();
        ds.setOffsetY(9.0f);
        ds.setColor(Color.BLACK);
 
        Text frase1 = new Text();
        frase1.setEffect(ds);
        frase1.setCache(true);
        frase1.setX(205.0f);
        frase1.setY(70.0f);
        frase1.setFill(Color.RED);
        frase1.setText("Yo solo se decir...");
        frase1.setFont(Font.font(null, FontWeight.BOLD, 40));
        
        ScaleTransition st1= new ScaleTransition(Duration.millis(5000), frase1);
        st1.setFromX(1.0);
        st1.setFromY(1.0);
        st1.setToX(0.0f);
        st1.setToY(0.0f);
        st1.setCycleCount(-1);
        st1.setAutoReverse(true);
        st1.play();
               
        Text frase2 = new Text();
        frase2.setEffect(ds);
        frase2.setCache(true);
        frase2.setX(370.0f);
        frase2.setY(135.0f);
        frase2.setFill(Color.RED);
        frase2.setText("De nada");
        frase2.setFont(Font.font(null, FontWeight.BOLD, 40)); 
        
        ScaleTransition st2= new ScaleTransition(Duration.millis(5000), frase2);
        st2.setFromX(1.0);
        st2.setFromY(1.0);
        st2.setToX(0.0f);
        st2.setToY(0.0f);
        st2.setCycleCount(-1);
        st2.setAutoReverse(true);
        st2.play();
        
        root.getChildren().addAll(frase1, frase2);
    }
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }
    
}
// Path = cabeza(ya), cabello(ya), arma(ya), ceja(ya)
//boca(ya), nadriz(ya), ojos(ya), expresion(ya)
//cuerpo, cinturon, collar, tatuajes
